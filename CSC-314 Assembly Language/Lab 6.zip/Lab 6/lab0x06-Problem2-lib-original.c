

int sumAtoB(int a, int b) {
   int i,s;
   i=a;
   s=0;
   while (i<=b){
      s=s+i;
      i=i+1;
   }
   return s;
}
